This directory contains archives and contributed files relevant to the
Cube-Lovers mailing list.  If you want to subscribe to the list (or
unsubscribe, or change your address) then send e-mail to
Cube-Lovers-Request@AI.MIT.EDU (but don't expect instantaneous
response--the list is maintained by a human).

To access the archives, use FTP to connect to FTP.AI.MIT.EDU, login as
"anonymous" (any password), and in the directory "pub/cube-lovers" you
will find the twenty-eight (compressed) files "cube-mail-0.gz" through
"cube-mail-27.gz".

Mail archive vital statistics (when uncompressed):

	   File		   From		   To	     Size (bytes)
	   ----		   ----		   --	     ------------
	cube-mail-0	12 Jul 80	23 Oct 80	185037
	cube-mail-1	 3 Nov 80	 9 Jan 81	135719
	cube-mail-2	10 Jan 81	 3 Aug 81	138566
	cube-mail-3	 3 Aug 81	 3 May 82	137753
	cube-mail-4	 4 May 82	11 Dec 82	139660
	cube-mail-5	11 Dec 82	 6 Jan 87	173364
	cube-mail-6	10 Jan 87	13 Apr 90	216733
	cube-mail-7	12 Oct 90	 9 Sep 91	137508
	cube-mail-8	 1 Nov 91	25 May 92	171205
	cube-mail-9	28 May 92	 7 Jan 93	155755
	cube-mail-10	20 Mar 93	 6 Dec 93	171881
	cube-mail-11	 6 Dec 93	18 Feb 94	349772
	cube-mail-12	24 Feb 94	 5 Sep 94	181193
	cube-mail-13	12 Sep 94	 8 Dec 94	282920
	cube-mail-14	10 Dec 94	12 Jan 95	278438
	cube-mail-15	14 Jan 95	19 May 95	325098
	cube-mail-16	19 May 95	 2 Sep 95	227806
	cube-mail-17	 4 Sep 95	20 Oct 95	148890
	cube-mail-18	21 Oct 95	 7 Jan 96	195429
	cube-mail-19	12 Jan 96	 3 May 96	155177
	cube-mail-20	 7 May 96	30 Jun 96	198116
	cube-mail-21	 2 Jul 96	17 Dec 96	188220
	cube-mail-22	17 Dec 96	 9 Jun 97	375038
	cube-mail-23	 9 Jun 97	26 Aug 97	339143
	cube-mail-24	26 Aug 97	 6 Mar 98	336970
	cube-mail-25	 8 Mar 98	14 Sep 98	346724
	cube-mail-26	14 Sep 98	20 Mar 99	440799
	cube-mail-27	21 Mar 99	11 Aug 99	306721

In addition, the file "recent-mail" contains a copy of the currently active
section of the mail archive.  (Due to the way the list is managed, it may
take a day or two before a new message arrives here.)

There is also a sub-directory, "contrib", that contains software and other
goodies contributed by our readers.

Finally, the file "README" contains the information you are currently reading.

On the World Wide Web you can access this archive using the URL
"ftp://ftp.ai.mit.edu/pub/cube-lovers". In Emacs, the name of this
directory is "/anonymous@ftp.ai.mit.edu:/pub/cube-lovers".

				- Alan
